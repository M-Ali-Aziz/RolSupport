=== Heroic Voting ===
Contributors: herothemes
Tags: voting, feedback
Requires at least: 3.5
Tested up to: 4.1
Stable tag: 1.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Heroic Voting is a simple voting plugin

== Description ==

For voting on posts.


== Installation ==

It's easy to get started

1. Upload `ht-voting` to the `/wp-content/plugins/` directory or goto Plugins>Add New and search for Heroic Voting.
2. Activate the plugin through the 'Plugins' menu in WordPress.

== Frequently Asked Questions ==



= Q. I have a another question or support query =

A. No worries, simply ask on the support section on WordPress.org.


== Screenshots ==

= 1.3 = 

Abstracted voting functionality with focus on knowledge base products

= 1.2 =

Improved ajax functionality and security
Added new display mode

= 1.1 =

Added ht_usefulness global function

= 1.0 =

Initial release.



current_theme_supports( 'hero-voting-frontend-styles' )